import type { Request, Response } from "express";
import { instructorService } from "../../services/admin/instructor.service.js";
import { createInstructorSchema, updateInstructorSchema } from "../../validators/admin/instructor.validator.js";

export const instructorController = {
  async getAll(req: Request, res: Response): Promise<void> {
    try {
      const instructors = await instructorService.getAll();
      res.status(200).json({ success: true, instructors });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  },

  async getById(req: Request, res: Response): Promise<void> {
    try {
      const instructor = await instructorService.getById(req.params.id as string);
      res.status(200).json({ success: true, instructor });
    } catch (err: any) {
      res.status(404).json({ success: false, message: err.message });
    }
  },

  async create(req: Request, res: Response): Promise<void> {
    const result = createInstructorSchema.safeParse(req.body);
    if (!result.success) {
      res.status(400).json({
        success: false,
        message: "Dados inválidos.",
        errors: result.error.flatten().fieldErrors,
      });
      return;
    }

    try {
      const instructor = await instructorService.create(result.data);
      res.status(201).json({ success: true, instructor });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  },

  async update(req: Request, res: Response): Promise<void> {
    const result = updateInstructorSchema.safeParse(req.body);
    if (!result.success) {
      res.status(400).json({
        success: false,
        message: "Dados inválidos.",
        errors: result.error.flatten().fieldErrors,
      });
      return;
    }

    try {
      const instructor = await instructorService.update(req.params.id as string, result.data);
      res.status(200).json({ success: true, instructor });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  },

  async delete(req: Request, res: Response): Promise<void> {
    try {
      await instructorService.delete(req.params.id as string);
      res.status(200).json({ success: true, message: "Formador apagado com sucesso." });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  },
};
